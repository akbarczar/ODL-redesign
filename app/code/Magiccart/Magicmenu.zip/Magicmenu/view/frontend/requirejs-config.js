var config = {
	map: {
		'*': {
			'magicmenu': "Magiccart_Magicmenu/js/magicmenu",
		},
	},

	// paths: {
	// 	'magicmenu'	: 'Magiccart_Magicmenu/js/magicmenu',
	// },

	shim: {
		'magicmenu': {
			deps: ['jquery', 'easing']
		},

	}

};
