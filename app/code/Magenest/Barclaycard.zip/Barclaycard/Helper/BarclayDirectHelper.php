<?php
/**
 * Created by Magenest JSC.
 * Date: 22/12/2020
 * Time: 9:41
 */
namespace Magenest\Barclaycard\Helper;

class BarclayDirectHelper
{
    protected $configData;
    protected $logger;


    public function __construct(
        \Magenest\Barclaycard\Helper\ConfigData $configData,
        \Magenest\Barclaycard\Helper\Logger $logger
    ) {
        $this->configData = $configData;
        $this->logger = $logger;
    }

    public function getRandomString($numberChar = 10)
    {
        $rand = substr(hash("sha256", microtime()), rand(0, 26), $numberChar);

        return $rand;
    }

    public function performPayment($data, $check = null)
    {
        ksort($data);
        $Passphrase = $this->configData->getShaInDirect(); // your SHA-IN pass phrase goes here
//        $data_string = "";
        $data_string = [];
        foreach ($data as $key => $value) {
            if($value){
                $data_string[] = $key . '=' . trim($value) . $Passphrase;
            }
//creates the string to hash
        }

        $string_post = [];
        $string_post = implode('', $data_string);
        $SHASign = hash($this->configData->getHashMethod(), $string_post);

        $data['SHASIGN'] = $SHASign;
        $post_string = [];
        foreach ($data as $key => $value) {
            $post_string[] = $key . '=' . $value;
        }

        $http_arr = [];
        foreach ($data as $key => $value) {
            $http_arr[$key] = $value;
        }


        //var_dump($post_string);
        $actual_string = [];
        $actual_string = implode('&', $post_string);
        $string  = http_build_query($http_arr);

        $request = curl_init($this->configData->getDirectPayUrl());
        curl_setopt($request, CURLOPT_HEADER, 0);
        curl_setopt($request, CURLOPT_HTTPHEADER, ["application/x-www-form-urlencoded"]);
        curl_setopt($request, CURLOPT_POST, 1);
        curl_setopt($request, CURLOPT_POSTFIELDS, $string);
        curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($request, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($request);
        curl_close($request);

        return $result;
    }

    public function genMaintenanceRequest(&$dataReceive)
    {
        $dataReceive['PSPID'] = $this->configData->getPspid();
        $dataReceive['PSWD'] = $this->configData->getPassword();
        $dataReceive['USERID'] = $this->configData->getUserId();
        ksort($dataReceive);
    }

    public function performMaintenance($data)
    {
        $Passphrase = $this->configData->getShaInDirect();
        $data_string = [];
        foreach ($data as $key => $value) {
            $data_string[] = $key . '=' . $value . $Passphrase;
        }
        $string_post = implode('', $data_string);
        $SHASign = hash($this->configData->getHashMethod(), $string_post);

        $data['SHASIGN'] = $SHASign;
        $post_string = [];
        foreach ($data as $key => $value) {
            $post_string[] = $key . '=' . $value;
        }
        foreach ($data as $key => $value) {
            $http_arr[$key] = $value;
        }
        $actual_string = [];
        $actual_string = implode('&', $post_string);
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        /** @var \Magento\Framework\HTTP\Client\Curl $curl */
        $curl = $objectManager->create('Magento\Framework\HTTP\Client\Curl');
        try {
            $curl->post($this->configData->getDirectMaintenanceUrl(), $http_arr);
            $result = $curl->getBody();
        } catch (\Exception $e) {
            $this->logger->debug($e->getMessage());
            $result = false;
        }

        return $result;
    }
}
