<?php
/**
 * Created by PhpStorm.
 * User: hiennq
 * Date: 12/22/16
 * Time: 00:01
 */

namespace Magenest\Barclaycard\Controller\Checkout;

use Magenest\Barclaycard\Controller\Checkout;
use Magenest\Barclaycard\Helper\Constant;

class ResponseDirect extends Checkout
{
    public function execute()
    {
        $this->barclayLogger->debug("3ds response: ");
    }
}
