<?php
/**
 * Created by Magenest.
 * Author: Joel
 * Date: 18/10/2016
 * Time: 10:29
 */

namespace Magenest\Barclaycard\Model;

use Magento\Payment\Model\CcGenericConfigProvider;

class ConfigProvider extends CcGenericConfigProvider
{
    protected $methodCodes = [
        BarclaycardPayment::CODE,
        BarclayDirect::CODE
    ];
}
