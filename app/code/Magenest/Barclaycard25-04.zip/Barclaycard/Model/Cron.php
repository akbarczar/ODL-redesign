<?php
/**
 * Created by PhpStorm.
 * User: hiennq
 * Date: 11/01/2018
 * Time: 16:40
 */

namespace Magenest\Barclaycard\Model;

use Magento\Framework\App\ObjectManager;

class Cron
{
    protected $chargeFactory;
    protected $configData;
    protected $orderFactory;

    public function __construct(
        \Magenest\Barclaycard\Model\ChargeFactory $chargeFactory,
        \Magenest\Barclaycard\Helper\ConfigData $configData,
        \Magento\Sales\Model\OrderFactory $orderFactory
    ) {
        $this->chargeFactory = $chargeFactory;
        $this->configData = $configData;
        $this->orderFactory = $orderFactory;
    }

    public function execute()
    {
//        $logger = ObjectManager::getInstance()->create('Magenest\Barclaycard\Helper\Logger');
//        $logger->debug("cronjob run");
        $expireMin = $this->configData->getOrderExpireMin();
        $secCheck = $expireMin * 60;
//        $logger->debug("sec check: ". $secCheck);
        $chargeCollection = $this->chargeFactory->create()->getCollection();
        $currentTime = time();
        foreach ($chargeCollection as $charge) {
            $createdAt = $charge->getData('created_at');
            $timestamp = strtotime($createdAt);
//            $logger->debug("current time : ". $currentTime);
//            $logger->debug("order timestamp : ". $timestamp);
            if (($timestamp + $secCheck) < $currentTime) {
//                $logger->debug("cancel order: " .$charge->getData('order_id'));
                $order = $this->orderFactory->create()->loadByIncrementId($charge->getData('order_id'));
                $order->addStatusHistoryComment("Order auto cancel by system");
                $order->cancel()->setState(
                    \Magento\Sales\Model\Order::STATE_CANCELED,
                    true,
                    'Order auto cancel by system'
                )->save();
                $charge->delete();
            }
        }
    }
}
