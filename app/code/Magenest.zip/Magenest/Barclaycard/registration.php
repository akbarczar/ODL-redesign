<?php
/**
 * Created by PhpStorm.
 * User: joel
 * Date: 17/10/2016
 * Time: 16:00
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Magenest_Barclaycard',
    __DIR__
);
